import pandas as pd
# Memuat dataset
df = pd.read_csv('Book1.csv')
# Menampilkan 5 baris pertama dataset
df.head()